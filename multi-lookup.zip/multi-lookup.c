#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "multi-lookup.h"
#include "util.h"
#include "queue.h"

pthread_mutex_t queue_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t doc_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t iter_lock = PTHREAD_MUTEX_INITIALIZER;

queue q;
FILE *results;
int req_threads_complete = 0;

void* requester(void* file){
	FILE *fpt;
	char* cur_file = file;
	char file_line[MAX_NAME_LENGTH];

	fpt = fopen(cur_file, "r");
	if(!fpt){
		perror("Error Opening Output File");
		exit(EXIT_FAILURE);
	}
	while(fgets(file_line, MAX_NAME_LENGTH, fpt)){
		pthread_mutex_lock(&queue_lock);
		while(queue_push(&q, strdup(file_line)) < 0){
			usleep(rand()%100);
		}
		pthread_mutex_unlock(&queue_lock);
	}

	fclose(fpt);

	pthread_mutex_lock(&iter_lock);
	req_threads_complete++;
	pthread_mutex_unlock(&iter_lock);
	return NULL;
}

void* resolver(void* address){
	char* cur_address = address;
	char hostname[MAX_NAME_LENGTH];
	char domain[MAX_IP_LENGTH];

	strncpy(hostname, cur_address, sizeof(hostname));

	if(dnslookup(hostname, domain, sizeof(domain))
	       == UTIL_FAILURE){
		fprintf(stderr, "dnslookup error: %s\n", hostname);
		strncpy(domain, "", sizeof(domain));
	    }

	pthread_mutex_lock(&doc_lock);
	fprintf(results, "%s,%s\n", cur_address, domain);
	pthread_mutex_unlock(&doc_lock);
	//printf("in resolver thread: %s", cur_address);

	return NULL;
}

int main(int argc, char *argv[]){
	pthread_t req_threads[MAX_INPUT_FILES];
	pthread_t res_threads[MAX_RESOLVER_THREADS];
	int rc;
	int res_thread_counter = 0;
	int res_thread_first_pass = 1;
	queue_init(&q, QUEUEMAXSIZE);

	if(argc < MINARGS){
		fprintf(stderr, "Not enough arguments: %d\n", (argc - 1));
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    	}
	if(argc > MAXARGS){
		fprintf(stderr, "Too many arguments: %d\n", (argc - 1));
                fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
                return EXIT_FAILURE;
	}

	for(int i = 1; i < argc - 1; i++){
		rc = pthread_create(&(req_threads[i-1]), NULL, requester, argv[i]);
		if (rc){
	    		printf("ERROR; return code from pthread_create() is %d\n", rc);
	    		return EXIT_FAILURE;
		}
	}

	results = fopen(argv[argc-1], "w");
	if(!results){
		perror("Error Opening Output File");
		return EXIT_FAILURE;
    	}

	while(1){
		pthread_mutex_lock(&queue_lock);
		int empty_queue = queue_is_empty(&q);
		pthread_mutex_unlock(&queue_lock);
		if(!empty_queue){
			if(!res_thread_first_pass)
				pthread_join(res_threads[res_thread_counter], NULL);
			pthread_mutex_lock(&queue_lock);
                	char* s = queue_pop(&q);
                	pthread_mutex_unlock(&queue_lock);

                	rc = pthread_create(&(res_threads[res_thread_counter]), NULL, resolver, s);
                	if (rc){
                        	printf("ERROR; return code from pthread_create() is %d\n", rc);
                        	exit(EXIT_FAILURE);
                	}
                	if(res_thread_counter == 9){
                        	res_thread_counter = 0;
                        	res_thread_first_pass = 0;
                	}
                	else
                        	res_thread_counter++;
		}
		else{
			pthread_mutex_lock(&iter_lock);
			int program_done = (req_threads_complete >= argc-1);
			pthread_mutex_unlock(&iter_lock);

			if(program_done){
				int thread_count;
				if(res_thread_first_pass)
					thread_count = res_thread_counter;
				else
					thread_count = MAX_RESOLVER_THREADS;
				for(int i = 0; i < thread_count; i++){
					pthread_join(res_threads[i], NULL);
				}
				queue_cleanup(&q);
				fclose(results);
				return EXIT_SUCCESS;
			}
		}
	}

	/*while(!queue_is_empty(&q)){
		printf("made it inside while loop");
		if(!res_thread_first_pass)
			pthread_join(res_threads[res_thread_counter], NULL);

		pthread_mutex_lock(&lock);
		char* s = queue_pop(&q);
		pthread_mutex_unlock(&lock);

		rc = pthread_create(&(req_threads[res_thread_counter]), NULL, resolver, s);
		if (rc){
                        printf("ERROR; return code from pthread_create() is %d\n", rc);
                        exit(EXIT_FAILURE);
                }
		if(res_thread_counter == 9){
			res_thread_counter = 0;
			res_thread_first_pass = 0;
		}
		else
			res_thread_counter++;
	}*/

	for(int i = 0; i < argc-1; i++){
		pthread_join(req_threads[i], NULL);
		//pthread_join(res_threads[i], NULL);
    	}

	/*while(!queue_is_empty(&q)){
		char* s = queue_pop(&q);
		printf("%s", s);
	}*/

	queue_cleanup(&q);
}
