#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "multi-lookup.h"
#include "util.h"
#include "queue.h"

pthread_mutex_t queue_lock = PTHREAD_MUTEX_INITIALIZER; //prevents race conditions in the queue
pthread_mutex_t doc_lock = PTHREAD_MUTEX_INITIALIZER; //prevents race conditions in results.txt
pthread_mutex_t iter_lock = PTHREAD_MUTEX_INITIALIZER; //prevents race conditions with req_threads_complete

queue q; //FIFO queue for domain names
FILE *results; //file that will contain the domain name and resulting ip addresses
int req_threads_complete = 0; //variable to keep track of how many requester threads have completed

//requester is designed to take a file as input and place each domain onto the queue one at a time
void* requester(void* file){
	FILE *fpt;
	char* cur_file = file;
	char file_line[MAX_NAME_LENGTH];

	fpt = fopen(cur_file, "r");
	if(!fpt){
		perror("Error Opening Output File");
		exit(EXIT_FAILURE);
	}
	while(fscanf(fpt, INPUTFS, file_line) > 0){
	//while(fgets(file_line, MAX_NAME_LENGTH, fpt)){
		pthread_mutex_lock(&queue_lock);
		while(queue_push(&q, strdup(file_line)) < 0){
			usleep(rand()%100);
		}
		pthread_mutex_unlock(&queue_lock);
	}

	fclose(fpt);

	pthread_mutex_lock(&iter_lock);
	req_threads_complete++;//one more requester thread is complete
	pthread_mutex_unlock(&iter_lock);
	return NULL;
}

//resolver is designed to take a web address as input, look up the IP, and place them both in results.txt
//if domain doesn't exist, an error is printed, and the domain is placed in results.txt without an IP
void* resolver(void* address){
	char* cur_address = address;
	char hostname[MAX_NAME_LENGTH];
	char domain[INET6_ADDRSTRLEN];

	strncpy(hostname, cur_address, sizeof(hostname));

	if(dnslookup(hostname, domain, sizeof(domain))
	       == UTIL_FAILURE){
		fprintf(stderr, "dnslookup error: %s\n", hostname);
		strncpy(domain, "", sizeof(domain));
	    }

	pthread_mutex_lock(&doc_lock);
	fprintf(results, "%s,%s\n", cur_address, domain);
	pthread_mutex_unlock(&doc_lock);

	return NULL;
}

int main(int argc, char *argv[]){
	pthread_t req_threads[MAX_INPUT_FILES]; //requester thread pool
	pthread_t res_threads[MAX_RESOLVER_THREADS]; //resolver thread pool
	int rc;
	int res_thread_counter = 0; //keeps track of where in the resolver pool to create a new thread
	int res_thread_first_pass = 1; //keeps track of whether or not the resolver pool has empty spaces

	queue_init(&q, QUEUEMAXSIZE);

	//check to see if at least 3 arguments are passed (the execution command, a file of domain names, and a file to print the output to)
	if(argc < MINARGS){
		fprintf(stderr, "Not enough arguments: %d\n", (argc - 1));
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    	}

	//check to see if 10 files or fewer were passed
	if(argc > MAXARGS){
		fprintf(stderr, "Too many arguments: %d\n", (argc - 1));
                fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
                return EXIT_FAILURE;
	}

	//create requester threads for each file passed
	for(int i = 1; i < argc - 1; i++){
		rc = pthread_create(&(req_threads[i-1]), NULL, requester, argv[i]);
		if (rc){
	    		printf("ERROR; return code from pthread_create() is %d\n", rc);
	    		return EXIT_FAILURE;
		}
	}

	//open results file
	results = fopen(argv[argc-1], "w");
	if(!results){
		perror("Error Opening Output File");
		return EXIT_FAILURE;
    	}

	//infinite loop that will continue until queue is empty and all requester threads have completed
	while(1){
		pthread_mutex_lock(&queue_lock);
		int empty_queue = queue_is_empty(&q);
		pthread_mutex_unlock(&queue_lock);

		//if queue isn't empty, create a resolver thread for next entry
		if(!empty_queue){
			//if this isn't the first pass, then we wait for the thread to join before creating a new thread in it's place
			//otherwise, assume the space is empty
			if(!res_thread_first_pass)
				pthread_join(res_threads[res_thread_counter], NULL);
			pthread_mutex_lock(&queue_lock);
                	char* s = queue_pop(&q);
                	pthread_mutex_unlock(&queue_lock);

                	rc = pthread_create(&(res_threads[res_thread_counter]), NULL, resolver, s);
                	if (rc){
                        	printf("ERROR; return code from pthread_create() is %d\n", rc);
                        	exit(EXIT_FAILURE);
                	}

			//if res_thread_counter has reached nine, that means all spaces in the resolver thread pool have been filled with a thread
			//and we can now start joining them on the second pass through
                	if(res_thread_counter == 9){
                        	res_thread_counter = 0;
                        	res_thread_first_pass = 0;
                	}
                	else
                        	res_thread_counter++;
		}
		//if the queue is empty, we check to see if the resolver threads have completed
		//NOTE: Just because the queue is empty does not mean the program is finished
		else{
			pthread_mutex_lock(&iter_lock);
			int program_done = (req_threads_complete >= argc-2);
			pthread_mutex_unlock(&iter_lock);

			//program is done if the queue is empty and req_threads_complete is equal to the amount of files passed into the arguments
			if(program_done){
				int thread_count;
				//if for some reason there was less than 10 domain names total, we only want to call join in spots that had threads
				if(res_thread_first_pass)
					thread_count = res_thread_counter;
				else
					thread_count = MAX_RESOLVER_THREADS;

				//wait for the rest of the resolver threads to join
				for(int i = 0; i < thread_count; i++){
					pthread_join(res_threads[i], NULL);
				}
				queue_cleanup(&q);
				fclose(results);
				return EXIT_SUCCESS;
			}
		}
	}
}
