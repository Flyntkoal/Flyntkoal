//Justin Daugherty
//010496968
//CSCI 440
//4-30-2023

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/wait.h>

#include "multi-lookup.h"
#include "util.h"

struct SharedInfo *S;

void init(){
	pthread_mutexattr_init(&(S->mutexAttr));
	pthread_mutexattr_setpshared(&(S->mutexAttr), PTHREAD_PROCESS_SHARED);
	pthread_mutex_init(&(S->queue_lock), &(S->mutexAttr));
	pthread_mutex_init(&(S->iter_lock), &(S->mutexAttr));
	pthread_mutex_init(&(S->doc_lock), &(S->mutexAttr));

	pthread_condattr_init(&(S->condAttr));
	pthread_condattr_setpshared(&(S->condAttr), PTHREAD_PROCESS_SHARED);
	pthread_cond_init(&(S->empty), &(S->condAttr));
	pthread_cond_init(&(S->fill), &(S->condAttr));

	S->store = 0;
	S->use = 0;
	S->count = 0;
}

void destruct(){
	pthread_condattr_destroy(&(S->condAttr));
	pthread_mutexattr_destroy(&(S->mutexAttr));
	pthread_mutex_destroy(&(S->queue_lock));
	pthread_mutex_destroy(&(S->iter_lock));
	pthread_mutex_destroy(&(S->doc_lock));
	pthread_cond_destroy(&(S->empty));
	pthread_cond_destroy(&(S->fill));
	munmap(S, sizeof(struct SharedInfo));
}

void put(char* value){
	strcpy(S->boundedbuff[S->store], value);
	S->store = (S->store + 1) % MAX_BUFFER_SIZE;
	S->count++;
}

int get(char* address){
	if(S->count > 0){
		strcpy(address, S->boundedbuff[S->use]);
		S->use = (S->use + 1) % MAX_BUFFER_SIZE;
		S->count--;
		return 1;
	}
	else{
		return 0;
	}
}

void requester(char* file){
	//printf("Starting process ID %d\n", processID);
	FILE *input;
	char file_line[MAX_NAME_LENGTH];
	
	input = fopen(file, "r");
	if(!input){
		perror("Error Opening Output File");
		exit(EXIT_FAILURE);
	}
	while(fscanf(input, INPUTFS, file_line) > 0){
		//printf("%d: waiting for queue_lock in requester\n", processID);
		pthread_mutex_lock(&(S->queue_lock));
		//printf("%d: queue_lock obtained in requester\n", processID);
		while(S->count == MAX_BUFFER_SIZE){
			//printf("%d: waiting for empty signal\n", processID);
			pthread_cond_wait(&(S->empty), &(S->queue_lock));
			//printf("%d: empty signal recieved\n", processID);
		}
		put(file_line);
		//printf("%d: sending fill signal\n", processID);
		pthread_cond_signal(&(S->fill));
		//printf("%d: queue unlocked in requester\n", processID);
		pthread_mutex_unlock(&(S->queue_lock));
	}
	
	//printf("%d: all addresses added to queue\n", processID);
	fclose(input);

	//printf("%d: Waiting for iter lock\n", processID);
	pthread_mutex_lock(&(S->iter_lock));
	//printf("%d: Req process complete\n", processID);
	S->req_procs_complete++;//one more requester thread is complete
	pthread_mutex_unlock(&(S->iter_lock));
	//printf("Process %d exited\n", processID);

	exit(EXIT_SUCCESS);
}

void resolver(){
	while(1){
		//printf("resolver loop invoked\n");
		char address[MAX_NAME_LENGTH];
		int program_done = 0;

		pthread_mutex_lock(&(S->queue_lock));
		while(!get(address)){
			pthread_mutex_lock(&(S->iter_lock));
			program_done = (S->req_procs_complete >= S->total_req_procs);
			//printf("req_procs_complete = %d and total_req_procs = %d\n", S->req_procs_complete, S->total_req_procs);
			pthread_mutex_unlock(&(S->iter_lock));
			if(program_done){
				//printf("program labled done\n");
				pthread_mutex_unlock(&(S->queue_lock));
				exit(EXIT_SUCCESS);
			}
			else{
				//printf("Waiting for fill signal\n");
				pthread_cond_wait(&(S->fill), &(S->queue_lock));
				//printf("Fill signal recieved\n");
			}

		}
		//printf("Sending empty signal\n");
		pthread_cond_signal(&(S->empty));
		pthread_mutex_unlock(&(S->queue_lock));

        	char domain[INET6_ADDRSTRLEN];

        	if(dnslookup(address, domain, sizeof(domain))
               	== UTIL_FAILURE){
                	fprintf(stderr, "dnslookup error: %s\n", address);
                	strncpy(domain, "", sizeof(domain));
            	}

        	pthread_mutex_lock(&(S->doc_lock));
        	fprintf(S->results, "%s,%s\n", address, domain);
        	pthread_mutex_unlock(&(S->doc_lock));
	}
}

int main(int argc, char *argv[]){
	pid_t req_procs[MAX_INPUT_FILES]; //requester process pool
	pid_t res_procs[MAX_RESOLVER_THREADS]; //resolver process pool
	int status;

	S = (struct SharedInfo *)mmap(NULL, sizeof(struct SharedInfo), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

	//check to see if at least 3 arguments are passed (the execution command, a file of domain names, and a file to print the output to)
	//This check is from lookup.c
	if(argc < MINARGS){
		fprintf(stderr, "Not enough arguments: %d\n", (argc - 2));
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    	}

	//check to see if 10 files or fewer were passed
	if(argc > MAXARGS){
		fprintf(stderr, "Too many arguments: %d\n", (argc - 2));
                fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
                return EXIT_FAILURE;
	}

	S->total_req_procs = argc-2;
	init();

	//open results file
        S->results = fopen(argv[argc-1], "w");
        if(!S->results){
                perror("Error Opening Output File");
                return EXIT_FAILURE;
        }

	//create requester processes for each file passed
	for(int i = 1; i < argc - 1; i++){
		if((req_procs[i-1] = fork()) == 0){
			requester(argv[i], getpid());
		}
	}
	
	//create 10 resolver threads
	for(int i = 0; i < MAX_RESOLVER_THREADS; i++){
		if((res_procs[i] = fork()) == 0){
                        resolver(getpid());
                }
	}

	/*//wait for all 10 resolver threads to complete
	for(int i = 0; i < MAX_RESOLVER_THREADS; i++){
		if(i < total_req_threads)
			pthread_join(req_threads[i], NULL);
		pthread_join(res_threads[i], NULL);
	}*/

	/*for(int i = 1; i < argc - 1; i++){
		wait(&status);
        }*/

	while(wait(&status) > 0);

	/*char address[MAX_BUFFER_SIZE];

	while(S->count > 0){
		get(address);
		printf("%s\n", address);
	}*/

        fclose(S->results);
	destruct();

	return EXIT_SUCCESS;
}
