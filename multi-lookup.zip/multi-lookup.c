//Justin Daugherty
//010496968
//CSCI 440
//4-30-2023

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/wait.h>

#include "multi-lookup.h"
#include "util.h"

struct SharedInfo *S;

//Initialize the locks and conditional variables, along with setting the indicies of the buffer
void init(){
	pthread_mutexattr_init(&(S->mutexAttr));
	pthread_mutexattr_setpshared(&(S->mutexAttr), PTHREAD_PROCESS_SHARED);
	pthread_mutex_init(&(S->buff_lock), &(S->mutexAttr));
	pthread_mutex_init(&(S->iter_lock), &(S->mutexAttr));
	pthread_mutex_init(&(S->doc_lock), &(S->mutexAttr));

	pthread_condattr_init(&(S->condAttr));
	pthread_condattr_setpshared(&(S->condAttr), PTHREAD_PROCESS_SHARED);
	pthread_cond_init(&(S->empty), &(S->condAttr));
	pthread_cond_init(&(S->fill), &(S->condAttr));

	S->store = 0;
	S->use = 0;
	S->count = 0;
}

//Free the memory of the locks, pointers, and the struct in memory
void destruct(){
	pthread_condattr_destroy(&(S->condAttr));
	pthread_mutexattr_destroy(&(S->mutexAttr));
	pthread_mutex_destroy(&(S->buff_lock));
	pthread_mutex_destroy(&(S->iter_lock));
	pthread_mutex_destroy(&(S->doc_lock));
	pthread_cond_destroy(&(S->empty));
	pthread_cond_destroy(&(S->fill));
	munmap(S, sizeof(struct SharedInfo));
}

//Function to put strings in the bounded buffer
//Returns a 1 if successful, and a 0 if buffer is full
int put(char* value){
	if(S->count < MAX_BUFFER_SIZE){
		strcpy(S->boundedbuff[S->store], value);
		S->store = (S->store + 1) % MAX_BUFFER_SIZE;
		S->count++;
		return 1;
	}
	else{
		return 0;
	}
}

//Function to get strings out of the bounded buffer
//Returns a 1 if successful, and a 0 if the buffer is empty
int get(char* address){
	if(S->count > 0){
		strcpy(address, S->boundedbuff[S->use]);
		S->use = (S->use + 1) % MAX_BUFFER_SIZE;
		S->count--;
		return 1;
	}
	else{
		return 0;
	}
}


//Takes a file name as input, opens the file, and puts each address into the bounded buffer
void requester(char* file){
	FILE *input;
	char file_line[MAX_NAME_LENGTH];
	
	input = fopen(file, "r");

	if(!input){
		perror("Error Opening Output File");
		exit(EXIT_FAILURE);
	}
	while(fscanf(input, INPUTFS, file_line) > 0){
		pthread_mutex_lock(&(S->buff_lock));

		//If the buffer is full, unlock the queue and wait for the empty variable to be triggerd by a resolver process
		while(!put(file_line)){
			pthread_cond_wait(&(S->empty), &(S->buff_lock));
		}
		//send a fill signal
		pthread_cond_signal(&(S->fill));
		pthread_mutex_unlock(&(S->buff_lock));
	}
	
	fclose(input);

	pthread_mutex_lock(&(S->iter_lock));
	S->req_procs_complete++;//one more requester thread is complete
	pthread_mutex_unlock(&(S->iter_lock));

	exit(EXIT_SUCCESS);
}

//continually pops off the buffer, resolves the address, and places both the address and domain in the results document
//If an address is not returned, check to see if the requesters are all finished. If so, kill the resolver process. Otherwise, wait for a fill signal
void resolver(){
	while(1){
		char address[MAX_NAME_LENGTH];
		int program_done = 0;

		pthread_mutex_lock(&(S->buff_lock));
		//If get(address) returns 0, the buffer is empty. Check to see if the program is done or not
		while(!get(address)){
			pthread_mutex_lock(&(S->iter_lock));
			program_done = (S->req_procs_complete >= S->total_req_procs);
			pthread_mutex_unlock(&(S->iter_lock));
			if(program_done){
				pthread_mutex_unlock(&(S->buff_lock));
				exit(EXIT_SUCCESS);
			}
			else{
				pthread_cond_wait(&(S->fill), &(S->buff_lock));
			}

		}
		//send an empty signal
		pthread_cond_signal(&(S->empty));
		pthread_mutex_unlock(&(S->buff_lock));

        	char domain[INET6_ADDRSTRLEN];

        	if(dnslookup(address, domain, sizeof(domain))
               	== UTIL_FAILURE){
                	fprintf(stderr, "dnslookup error: %s\n", address);
                	strncpy(domain, "", sizeof(domain));
            	}

        	pthread_mutex_lock(&(S->doc_lock));
        	fprintf(S->results, "%s,%s\n", address, domain);
        	pthread_mutex_unlock(&(S->doc_lock));
	}
}

int main(int argc, char *argv[]){
	pid_t req_procs[MAX_INPUT_FILES]; //requester process pool
	pid_t res_procs[MAX_RESOLVER_THREADS]; //resolver process pool
	int status;//get status while main process waits for all children to finish

	//Map struct into shared memory so all processes can access
	S = (struct SharedInfo *)mmap(NULL, sizeof(struct SharedInfo), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

	//check to see if at least 3 arguments are passed (the execution command, a file of domain names, and a file to print the output to)
	//This check is from lookup.c
	if(argc < MINARGS){
		fprintf(stderr, "Not enough arguments: %d\n", (argc - 2));
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return EXIT_FAILURE;
    	}

	//check to see if 10 files or fewer were passed
	if(argc > MAXARGS){
		fprintf(stderr, "Too many arguments: %d\n", (argc - 2));
                fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
                return EXIT_FAILURE;
	}

	S->total_req_procs = argc-2;
	init();

	//open results file
        S->results = fopen(argv[argc-1], "w");
        if(!S->results){
                perror("Error Opening Output File");
                return EXIT_FAILURE;
        }

	//create requester processes for each file passed
	for(int i = 1; i < argc - 1; i++){
		if((req_procs[i-1] = fork()) == 0){
			requester(argv[i]);
		}
	}
	
	//create 10 resolver processes
	for(int i = 0; i < MAX_RESOLVER_THREADS; i++){
		if((res_procs[i] = fork()) == 0){
                        resolver();
                }
	}

	//wait for all process to finish
	while(wait(&status) > 0);

        fclose(S->results);
	destruct();

	return EXIT_SUCCESS;
}
