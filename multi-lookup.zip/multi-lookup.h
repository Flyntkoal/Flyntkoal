//Justin Daugherty
//CSCI 440
//4-30-2023

#ifndef MULTI_LOOKUP_H
#define MULTI_LOOKUP_H

#include <pthread.h>

#define MAX_INPUT_FILES 10
#define MINARGS 3
#define MAXARGS 12
#define MAX_RESOLVER_THREADS 2
#define MIN_RESOLVER_THREADS 2
#define MAX_NAME_LENGTH 1025
#define MAX_IP_LENGTH INET6_ADDRSTRLEN
#define MAX_BUFFER_SIZE 50
#define INPUTFS "%1024s"
#define USAGE "<inputFilePath> <outputFilePath>"

struct SharedInfo {
	pthread_mutex_t queue_lock; //prevents race conditions in the queue
	pthread_mutex_t doc_lock; //prevents race conditions in results.txt
	pthread_mutex_t iter_lock; //prevents race conditions with req_threads_comp	lete
	pthread_mutexattr_t mutexAttr;
	pthread_condattr_t condAttr;
        FILE *results; //file that will contain the domain name and resulting ip addresses
        pthread_cond_t empty, fill;
        char boundedbuff[MAX_BUFFER_SIZE][MAX_NAME_LENGTH]; //Bounded buffer for domain names
        int store;
        int use;
        int count;
        int total_req_procs; //variable to keep track of how many requester threads in total are going to be used by the program
        int req_procs_complete; //variable to keep track of how many requester threads have completed
};

void init();
void destruct();
void put(char* value);
int get(char* address);
void requester(char* file, pid_t processID);
void resolver(pid_t processID);
#endif
