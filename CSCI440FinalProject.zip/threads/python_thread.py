import time
import multiprocessing

def deposit(balance, lock):
    for i in range(100):
        time.sleep(0.01)
        lock.acquire()
        balance.value = balance.value + 1
        lock.release()


def withdraw(balance, lock):
    for i in range(100):
        time.sleep(0.01)
        lock.acquire()
        balance.value = balance.value - 1
        lock.release()

if __name__ == '__main__':
    thread_count = 100
    deposit_threads = []
    withdraw_threads = []
    balance = multiprocessing.Value('i', 200)
    lock = multiprocessing.Lock()
    start = time.time_ns()
    for i in range(thread_count):
        deposit_threads.append(multiprocessing.Process(target=deposit, args=(balance,lock)))
        deposit_threads[i].start()

        withdraw_threads.append(multiprocessing.Process(target=withdraw, args=(balance,lock)))
        withdraw_threads[i].start()
    
    for i in range(thread_count):
        deposit_threads[i].join()
        withdraw_threads[i].join()

    end = time.time_ns()
    time_diff = end-start
    time_diff_s = time_diff / (10 ** 9)
    print("Time taken = {0:.6f} seconds".format(time_diff_s))
