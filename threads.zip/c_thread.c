#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>

int balance = 200;
pthread_mutex_t balance_lock = PTHREAD_MUTEX_INITIALIZER;
//pthread_mutex_t deposit_average_lock = PTHREAD_MUTEX_INITIALIZER;
//pthread_mutex_t withdraw_average_lock = PTHREAD_MUTEX_INITIALIZER;

void* deposit(void* v){
	for(int i = 0; i < 100; i++){
		usleep(0.01);
		pthread_mutex_lock(&balance_lock);
		balance++;
		pthread_mutex_unlock(&balance_lock);
		//printf("balance increased\n");
	}
}

void* withdraw(void* v){
	for(int i = 0; i < 100; i++){
                usleep(0.01);
                pthread_mutex_lock(&balance_lock);
                balance--;
                pthread_mutex_unlock(&balance_lock);
		//printf("balanced decreased\n");
        }
}

int main(){
	int thread_count = 100;
	pthread_t depositer[thread_count];
	pthread_t withdrawer[thread_count];

	struct timespec start, end;
        clock_gettime(CLOCK_MONOTONIC, &start);

	for(int i = 0; i < thread_count; i++){
		pthread_create(&(depositer[i]), NULL, deposit, NULL);
		pthread_create(&(withdrawer[i]), NULL, withdraw, NULL);
	}

	for(int i = 0; i < thread_count; i++){
                pthread_join(depositer[i], NULL);
	        pthread_join(withdrawer[i], NULL);
        }

	clock_gettime(CLOCK_MONOTONIC, &end);
        double time_taken;
        time_taken = (end.tv_sec - start.tv_sec) * 1e9;
        time_taken = (time_taken + (end.tv_nsec - start.tv_nsec)) * 1e-9;
        
	printf("Time taken = %.6f seconds\n", time_taken);

}

